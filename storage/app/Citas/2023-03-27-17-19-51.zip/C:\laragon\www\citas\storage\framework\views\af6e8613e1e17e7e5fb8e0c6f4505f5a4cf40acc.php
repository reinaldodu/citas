<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Atender cita')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                  <div class="flex justify-center">
                    
                        <div class="card w-96 bg-base-100 shadow-xl">
                            <figure class="px-10 pt-10">
                            <img src="https://source.unsplash.com/random/200x200/?face" alt="foto" class="rounded-full" />
                            </figure>
                            <div class="card-body">
                            <h2 class="card-title"><?php echo e($cita->paciente->nombres . ' ' . $cita->paciente->apellidos); ?></h2>
                            <div class="divider"></div> 
                            <p> <span class="font-semibold">Documento:</span> <?php echo e($cita->paciente->documento); ?></p>
                            <p> <span class="font-semibold">Edad:</span> <?php echo e($cita->paciente->edad); ?> años</p>
                            <p> <span class="font-semibold">Teléfono:</span> <?php echo e($cita->paciente->telefono); ?></p>
                            <p> <span class="font-semibold">Email:</span> <?php echo e($cita->paciente->email); ?></p>
                            
                            <p> <span class="font-semibold">Observación:</span> <?php echo e($cita->observacion); ?></p>
                            <p> <span class="font-semibold">Diagnóstico:</span> <?php echo e($cita->diagnostico); ?></p>
                            <p> <span class="font-semibold">Medicamento:</span> <?php echo e($cita->medicamento); ?></p>

                        
                            <div class="card-actions justify-end mt-10">
                            <a href="<?php echo e(route('citas.atender', $cita)); ?>" class="btn btn-xs btn-outline btn-primary">
                                Editar
                            </a>
                            
                            <a href="<?php echo e(route('citas.agenda_dia')); ?>" class="btn btn-xs btn-outline btn-primary">
                                Cancelar
                            </a>
                            </div>
                            </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\citas\resources\views/citas/detalle.blade.php ENDPATH**/ ?>