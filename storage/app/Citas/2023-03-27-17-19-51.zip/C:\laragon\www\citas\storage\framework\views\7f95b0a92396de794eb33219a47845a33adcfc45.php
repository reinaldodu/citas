 

<?php $__env->startSection('title', $procedimiento->nombre); ?>

<?php $__env->startSection('content'); ?>
    <div class="hero min-h-screen bg-base-200">
      <div class="hero-content flex-col lg:flex-row">
        <img src="https://source.unsplash.com/random/300x300/?doctor&image=6" class="max-w-sm rounded-lg shadow-2xl" />
        <div>
          <h1 class="text-5xl font-bold"><?php echo e($procedimiento->nombre); ?></h1>
          <p class="py-6"><?php echo e($procedimiento->descripcion); ?></p>
          <button class="btn btn-primary">Solicitar cita</button>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\citas\resources\views/ver_procedimiento.blade.php ENDPATH**/ ?>