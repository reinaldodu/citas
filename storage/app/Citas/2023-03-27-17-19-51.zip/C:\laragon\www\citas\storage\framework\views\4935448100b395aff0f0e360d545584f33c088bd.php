<ul class="p-2 z-10  bg-orange-400 text-white">
    <?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('ver_procedimiento', $procedimiento)); ?>"><?php echo e($procedimiento->nombre); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\laragon\www\citas\resources\views/partials/lista_procedimientos.blade.php ENDPATH**/ ?>