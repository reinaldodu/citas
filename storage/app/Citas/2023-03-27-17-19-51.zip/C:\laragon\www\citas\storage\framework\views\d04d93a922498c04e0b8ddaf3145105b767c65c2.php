<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmación cita</title>
</head>
<body>
    <h1>Su cita ha sido agendada</h1>    
    <p>Estimado(a) paciente <?php echo e($mailData["nombre"]); ?>, su cita ha sido asignada exitosamente.</p>
    <p>Los detalles de su cita son los siguientes:</p>
    <p>Fecha: <?php echo e($mailData["fecha"]); ?></p>
    <p>Hora: <?php echo e($mailData["hora"]); ?></p>
    <p>Procedimiento: <?php echo e($mailData["procedimiento"]); ?></p>
    <p>Médico: <?php echo e($mailData["medico"]); ?></p>
    <br>
    <p>Agradecemos su preferencia.</p>
</body>
</html><?php /**PATH C:\laragon\www\citas\resources\views/emails/envioMail.blade.php ENDPATH**/ ?>