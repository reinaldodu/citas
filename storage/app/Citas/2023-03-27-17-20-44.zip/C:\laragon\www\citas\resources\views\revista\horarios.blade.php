@extends('layouts.main')

@section('title', 'Horarios')

@section('content')

<BR></BR>
<h1 align="center" style="font-size: 2em;">Horarios de atención</h1><br>

<div class="container">
  <div class="card w-96 bg-base-100 border shadow-xl ">
    <figure class="px-10 pt-10">
    <div class="overflow-x-auto" style="width: 70%; margin: 0 auto;">
  <table class="table table-zebra w-full">
    <thead>
      <tr>
        <th>Día</th>
        <th>Horario de atención</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th>Lunes</th>
        <td>10:00 am – 4:00 pm</td>
      </tr>
      <tr>
      <th>Martes</th>
        <td>10:00 am – 4:00 pm</td>
      </tr>
      <tr>
      <th>Miércoles</th>
        <td>10:00 am – 4:00 pm</td>
      </tr>
      <th>Jueves</th>
        <td>10:00 am – 4:00 pm</td>
      </tr>
      <th>Viernes</th>
        <td>10:00 am – 2:00 pm</td>
      </tr>
      <th>Sábado</th>
        <td>No hay servicio</td>
      </tr>
      <th>Domingo</th>
        <td>No hay servicio</td>
    </tbody>
  </table>    </figure>
  <br>
    <div class="card-body items-center text-center">
      <p style="font-size:13px;">Los horarios pueden estar sujetos a cambios</p>
    
    </div>
  </div>
</div>
<br>
    <section class="cancellation-policy">
      <h2>Política de cancelación de citas</h2>
      <p>Entendemos que a veces puede ser necesario cancelar una cita médica. Por favor, tenga en cuenta lo siguiente:</p>
      <ul>
      <li>Si necesita cancelar o reprogramar su cita, le pedimos que nos avise con al menos 24 horas de anticipación. De esta manera, podemos programar a otro paciente en su lugar.</li>
              <li>Si recomienda su puntual asistencia a la cita asignada</li>
              <li>Si tiene alguna pregunta o necesita ayuda para cancelar o reprogramar su cita, no dude en ponerse en contacto con nosotros. Estamos aquí para ayudarlo.</li>
            </ul>
      </ul>
    </section>
</div>

<style>
   .container {
  display: flex;
  justify-content: center;
  align-items: center;
}
 label{
  color:black;
}
.card {
  width:900px;
  margin-left: 100px;
  box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.2);
  border: 1px solid black;
  border-radius: 10px;
  overflow: hidden;
}

.cancellation-policy {
  background-color: #e2e2e2;
  border: 1px solid #ccc;
  padding: 20px;
  margin-bottom: 20px;
  color:#091a32;
  border-radius:10px;

}

.cancellation-policy h2 {
  font-size: 20px;
  margin-bottom: 10px;
}

.cancellation-policy p {
  font-size: 15px;
  margin-bottom: 10px;
}

.cancellation-policy ul {
  list-style: disc;
  margin-left: 20px;
  font-size: 16px;
}

.cancellation-policy li {
  margin-bottom: 5px;
  font-size:15px;
}

  </style>
@endsection