<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Lista de usuarios')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    <?php if(session("info")): ?>
                    <div class="alert alert-success shadow-lg">
                        <div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current flex-shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            <span><?php echo e(session("info")); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>


                    
                    <div class="flex justify-end mb-6 mt-5">
                        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success">Crear Usuario</a>
                    </div>
                    
                    <!--Filtros-->
                    <div class="flex justify-between mb-10">
                        <!--Filtrar por nombre-->
                        <div class="flex justify-start">
                           <form action="<?php echo e(route('usuarios.index')); ?>" method="GET">
                                <div>
                                    <input class="input input-bordered input-sm" type="text" name="nombre" placeholder="Buscar por nombre">
                                    <button type="submit" class="btn btn-primary ml-2 btn-xs">Buscar</button>
                                </div>
                           </form>
                        </div>
                        <!--Filtrar por rol-->

                        <div class="flex justify-end space-x-4">
                            <p>Filtros:</p>
                            <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-outline btn-xs btn-success rounded-xl">Todos</a>
                            <a href="<?php echo e(route('usuarios.index',['rol'=>1])); ?>" class="btn btn-outline btn-xs btn-success rounded-xl">Administradores</a>
                            <a href="<?php echo e(route('usuarios.index',['rol'=>2])); ?>" class="btn btn-outline btn-xs btn-success rounded-xl">Médicos</a>
                            <a href="<?php echo e(route('usuarios.index',['rol'=>3])); ?>" class="btn btn-outline btn-xs btn-success rounded-xl">Pacientes</a>
                        </div>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="table table-zebra w-full" >
                          <!-- head -->
                          <thead>
                            <tr>
                              <th>Nombre</th>
                              <th></th>
                              <th>Documento</th>
                              <th>Fecha_nacimiento</th>
                              <th>Teléfono</th>
                              <th>Email</th>
                              <th>Rol</th>
                              <th>Estado</th>
                              <th></th>
                            </tr>
                          </thead>
                          <tbody>
                            <!-- row 1 -->
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                <?php echo e($usuario->nombres .' ' . $usuario->apellidos); ?>


                                </td>
                                <td>
                                    <div class="tooltip tooltip-right" data-tip=" Consultar usuario: <?php echo e($usuario->nombres .' ' . $usuario->apellidos); ?>"">
                                    <a class="font-bold btn-xs btn-primary rounded-lg" href="<?php echo e(route('usuarios.show', $usuario->id)); ?>">
                                Detalles
                                </a>
                                    </div>
                                </td>
                                <td><?php echo e($usuario->documento); ?></td>
                                <td>
                                    <?php echo e($usuario->fecha_nacimiento); ?>

                                    <div class="badge badge-sm badge-outline">
                                        <?php echo e($usuario->edad); ?> años
                                    </div>
                                </td>
                                <td><?php echo e($usuario->telefono); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td><?php echo e($usuario->rol->nombre); ?></td>
                                <td><?php echo e($usuario->activo); ?></td>
                                <td>
                                    
                                    <div class="tooltip tooltip-left" data-tip="Editar <?php echo e($usuario->name); ?>">
                                        <a href="<?php echo e(route('usuarios.edit', $usuario)); ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--ic" width="16" height="16" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="#888888" d="m14.06 9.02l.92.92L5.92 19H5v-.92l9.06-9.06M17.66 3c-.25 0-.51.1-.7.29l-1.83 1.83l3.75 3.75l1.83-1.83a.996.996 0 0 0 0-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29zm-3.6 3.19L3 17.25V21h3.75L17.81 9.94l-3.75-3.75z"></path></svg>
                                        </a>
                                    </div>
                                    
                                    
                                    <?php if($usuario->estado == 1): ?>
                                        <div class="tooltip tooltip-left" data-tip="Desactivar <?php echo e($usuario->name); ?>">
                                            <form action="<?php echo e(route('usuarios.estado', $usuario->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit" class="btn-ghost rounded-lg" onclick="return confirm('¿Desea desactivar el usuario?')">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M22 10.5h-6m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
                                                      </svg>
                                                </button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                        
                                        <div class="tooltip tooltip-left" data-tip="Activar <?php echo e($usuario->name); ?>">
                                            <form action="<?php echo e(route('usuarios.estado', $usuario->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit" class="btn-ghost rounded-lg" onclick="return confirm('¿Desea activar el usuario?')">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" width="16" height="16" class="w-4 h-4">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
                                                    </svg>

                                                      
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                    
                                    
                                    
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                      
                        <div class="mt-5">
                            <?php echo e($usuarios->links()); ?>

                        </div>
                </div>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\citas\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>